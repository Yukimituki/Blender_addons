bl_info = {
    "name": "image to Photoshop",
    "description": "イメージをPhotoshopで開く",
    "author": "Yukimi",
    "version": (0,3),
    "blender": (2, 6, 0),
    "location": "image",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}

import bpy
import os
import subprocess
import time
import random

#実行するjavascriptの名前
js_name = "img_open.jsx"
#このスクリプトのあるディレクトリのパス
mydoc_dir = os.path.dirname(__file__)
#実行するスクリプトのパス
VB_Hub = os.path.abspath(os.path.join(mydoc_dir, "VB_Hub.vbs"))
jscript = os.path.abspath(os.path.join(mydoc_dir, js_name))
#Blenderの一時ファイルのパス
tmp_dir = bpy.context.user_preferences.filepaths.temporary_directory

def to_photoshop(context):
    #現在の.blendファイルのあるフォルダに一時ファイルを保存する場合は以下２行をコメントアウト
    #blendpath = bpy.data.filepath
    #tmp_dir  = os.path.join(os.path.split(blendpath)[0],"tmp")
    #日時+3桁のランダムアルファベットでファイル名の作成
    source_str = 'abcdefghijklmnopqrstuvwxyz'
    f_name = time.strftime("%y%m%d%H%M") + "".join([random.choice(source_str) for x in range(3)]) + ".png"
    img_path  = os.path.join(tmp_dir,f_name)
    #表示している画像の保存
    bpy.ops.image.save_as(save_as_render=False, filepath=img_path, relative_path=True)
    #スクリプトの実行
    subprocess.call(["CScript", VB_Hub, jscript, img_path, "//nologo"])
    

###################################################
class DupulicateActionAtCurrentTime(bpy.types.Operator):
    '''add Roop  '''
    bl_idname = "action.to_photoshop"
    bl_label = "open imege on Photoshop"
    def execute(self, context):
        to_photoshop(context)
        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator("action.to_photoshop", 
        text="Photoshopで開く" )

def register():
    bpy.utils.register_module(__name__)
    bpy.types.IMAGE_MT_image.prepend(menu_func)

def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.IMAGE_MT_image.remove(menu_func)

if __name__ == "__main__":
    register()
##########################################################