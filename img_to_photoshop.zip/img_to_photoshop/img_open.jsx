﻿#target photoshop
app.active
var active_doc = app.activeDocument
//引数で指定したドキュメントを開いて現在のPSDに複製
if (arguments.length > 0){
    var img_file =  File(arguments[0])
    var img = app.open( img_file );
    img.artLayers[0].duplicate(active_doc)
    img.close()
    }

active_doc.active